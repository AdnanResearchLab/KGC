import pykeen.pipeline as pipeline

def train_model(model_name, train_path, test_path, epochs=50):
    result = pipeline(
        training=train_path,
        testing=test_path,
        model=model_name,
        training_kwargs=dict(num_epochs=epochs)
    )
    result.save_to_directory(f'experiments/{model_name.lower()}')
    return result
