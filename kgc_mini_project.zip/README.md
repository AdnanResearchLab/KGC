# Knowledge Graph Completion Mini Project

This repository is a starter kit for MS-level students to learn Knowledge Graph Completion using PyTorch and PyKEEN.

## Folder Structure

- data/: raw and processed datasets
- notebooks/: Jupyter notebooks for preprocessing, training, and evaluation
- src/: source code (trainer, data loader, models)
- experiments/: folder to save model experiments
- results/: folder to save metrics and plots
- requirements.txt: Python dependencies

## Quick Start

1. Install dependencies:
```
pip install -r requirements.txt
```
2. Run notebooks in order:
   - 01_load_data.ipynb
   - 02_train_transe.ipynb
   - 03_evaluate.ipynb

3. Push your results to `results/` and experiments to `experiments/`.
